﻿using MediaUpload.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace MediaUpload.Controllers
{
  
    public class HomeController : Controller
    {
        private readonly string MediaDestination;
        private readonly ILogger<HomeController> _logger;

        
        public HomeController(IWebHostEnvironment env, IOptions<HomeControllerOptions> options, ILogger<HomeController> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            MediaDestination = Path.Combine(env?.WebRootPath ?? throw new ArgumentNullException(nameof(env)),
                               options?.Value?.MediaFolderName ?? throw new ArgumentNullException(nameof(options)));
        }

       
        public IActionResult Index()
        {
            try
            {
                var model = Directory.GetFiles(MediaDestination, "*.mp4")
                .Select(f => new MediaUploadModel
                {
                    FileName = Path.GetFileName(f),
                    FileSize = new FileInfo(f).Length
                }).ToList();

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching videos in Index method.");
                throw;
            }
        }

       
        public IActionResult Play(string fileName)
        {
            try
            {
                var filePath = Path.Combine(MediaDestination, fileName);
                if (!System.IO.File.Exists(filePath))
                {
                    return NotFound();
                }

                return PhysicalFile(filePath, "video/mp4");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error playing video: {fileName}");
                throw;
            }
        }

       
        [HttpGet]
        public IActionResult GetVideos()
        {
            try
            {
                var videos = Directory.GetFiles(MediaDestination, "*.mp4")
                   .Select(f => new MediaUploadModel
                   {
                       FileName = Path.GetFileName(f),
                       FileSize = new FileInfo(f).Length
                   }).ToList();

                return Json(videos);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching videos in GetVideos method.");
                throw;
            }
        }
    }
}
