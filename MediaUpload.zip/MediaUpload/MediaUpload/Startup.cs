﻿using MediaUpload.Controllers;
using MediaUpload.Models;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Options;

namespace MediaUpload
{
    

    
       
        public class Startup
        {
            private const long MaxFileSizeBytes = 200 * 1024 * 1024; // 200 MB limit

            public IConfiguration Configuration { get; }

          
            public Startup(IConfiguration configuration)
            {
                Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            }

            
            public void ConfigureServices(IServiceCollection services)
            {
               
                services.AddControllersWithViews();

                
                services.Configure<FormOptions>(options =>
                {
                    options.MultipartBodyLengthLimit = MaxFileSizeBytes; 
                });

              
                services.Configure<HomeControllerOptions>(Configuration.GetSection("HomeControllerOptions"));

               
                services.AddTransient<HomeController>((serviceProvider) =>
                {
                    var env = serviceProvider.GetRequiredService<IWebHostEnvironment>();
                    var logger = serviceProvider.GetRequiredService<ILogger<HomeController>>();
                    var options = serviceProvider.GetRequiredService<IOptions<HomeControllerOptions>>();

                    return new HomeController(env, options, logger);
                });
            }

           
            public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
            {
                if (env.IsDevelopment())
                {
                    app.UseDeveloperExceptionPage();
                }
                else
                {
                    app.UseExceptionHandler("/Home/Error");
                    app.UseHsts();
                }

                app.UseHttpsRedirection();
                app.UseStaticFiles();

                app.UseRouting();

                app.UseAuthorization();

                app.UseEndpoints(endpoints =>
                {
                    endpoints.MapControllerRoute(
                        name: "default",
                        pattern: "{controller=Home}/{action=Index}/{id?}");
                });
            }
        }
    

}


