﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace MediaUpload.Models
{
    public class MediaUploadModel
    {

        /// <summary>
        /// Gets or sets the name of the video file.
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets the size of the video file in bytes.
        /// </summary>
        public long FileSize { get; set; }


    }
}

