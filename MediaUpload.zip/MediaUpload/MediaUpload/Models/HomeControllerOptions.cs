﻿namespace MediaUpload.Models
{
    public class HomeControllerOptions
    {
       
        public string MediaFolderName { get; set; }


       
        public long MaxFileSizeBytes { get; set; }
    }
}
